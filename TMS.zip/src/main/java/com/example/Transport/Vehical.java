package com.example.Transport;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;
import java.util.List;

public class Vehical extends AppCompatActivity {

    DatabaseHelper_vehicals databaseHelper;
    TextView datalist;
    TextView datalist_count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehical);

        databaseHelper =new DatabaseHelper_vehicals(Vehical.this);
        Button delete=findViewById(R.id.delete_data);
        Button insert=findViewById(R.id.insert_data);
        Button update=findViewById(R.id.update_data);
        Button read=findViewById(R.id.refresh_data);
        datalist=findViewById(R.id.all_data_list);
        datalist_count=findViewById(R.id.data_list_count);

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshData();

            }
        });

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowInputDialog();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showUpdateIdDialog();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog();
            }
        });
    }


    private void refreshData() {
        datalist_count.setText("ALL DATA COUNT : "+ databaseHelper.getTotalCount());

        List<vehicalx> studentModelList= databaseHelper.getAllvehicals();
        datalist.setText("");
        for(vehicalx studentModel:studentModelList){
            datalist.append("ID : "+studentModel.getId()+" \n  | registrationdate : "+studentModel.getRegistrationdate()+" \n  | Vehicalno : "+studentModel.getVehicalno()+" \n  | taxvalidupto : "+studentModel.getTaxvalidupto()+ " \n  | fitnessvalidupto : "+studentModel.getFitnessvalidupto()+"\n  | insuranceupto : "+studentModel.getInsurancevalidupto()+ " \n  | pucvalidupto : "+studentModel.getPucvalidupto()+ " \n  | permitvalidupto : "+studentModel.getPermitvalidupto()+ "    \n\n\n");
        }
    }

    private void showDeleteDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Vehical.this);
        View view=getLayoutInflater().inflate(R.layout.delete_dialog_vehical,null);
        al.setView(view);
        final EditText id_input=view.findViewById(R.id.id_input);
        Button delete_btn=view.findViewById(R.id.delete_btn);
        final AlertDialog alertDialog=al.show();

        delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.deletevehicals(id_input.getText().toString());
                alertDialog.dismiss();
                refreshData();

            }
        });


    }

    private void showUpdateIdDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Vehical.this);
        View view=getLayoutInflater().inflate(R.layout.update_id_dialog_vehical,null);
        al.setView(view);
        final EditText id_input=view.findViewById(R.id.id_inputvehical);
        Button fetch_btn=view.findViewById(R.id.update_id_btnvehical);
        final AlertDialog alertDialog=al.show();

        fetch_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDataDialog(id_input.getText().toString());
                alertDialog.dismiss();
                refreshData();
            }
        });

    }

    private void showDataDialog(final String id) {
        vehicalx studentModel = databaseHelper.getvehical(Integer.parseInt(id));
        AlertDialog.Builder al=new AlertDialog.Builder(Vehical.this);
        View view=getLayoutInflater().inflate(R.layout.update_dialog_vehical,null);
        final EditText registrationdate=view.findViewById(R.id.registrationdate);
        final EditText vehicalno=view.findViewById(R.id.vehicalno);
        final EditText taxvalidupto=view.findViewById(R.id.taxvalidupto);
        final EditText fitnessvalidupto=view.findViewById(R.id.fitnessvalidupto);
        final EditText insurancevalidupto=view.findViewById(R.id.insurancevalidupto);
        final EditText pucvalidupto=view.findViewById(R.id.pucvalidupto);
        final EditText permitvalidupto=view.findViewById(R.id.permitvalidupto);


        Button update_btn=view.findViewById(R.id.update_id_btnvehical);
        al.setView(view);

        registrationdate.setText(studentModel.getRegistrationdate());
        vehicalno.setText(studentModel.getVehicalno());
        taxvalidupto.setText(studentModel.getTaxvalidupto());
        fitnessvalidupto.setText(studentModel.getFitnessvalidupto());
        insurancevalidupto.setText(studentModel.getInsurancevalidupto());
        pucvalidupto.setText(studentModel.getPucvalidupto());
        permitvalidupto.setText(studentModel.getPermitvalidupto());



        final AlertDialog alertDialog=al.show();
        update_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vehicalx studentModel=new vehicalx();
                studentModel.setId(id);
                studentModel.setRegistrationdate(registrationdate.getText().toString());
                studentModel.setVehicalno(vehicalno.getText().toString());
                studentModel.setTaxvalidupto(taxvalidupto.getText().toString());
                studentModel.setFitnessvalidupto(taxvalidupto.getText().toString());
                studentModel.setFitnessvalidupto(fitnessvalidupto.getText().toString());
                studentModel.setInsurancevalidupto(insurancevalidupto.getText().toString());
                studentModel.setPucvalidupto(pucvalidupto.getText().toString());
                studentModel.setPermitvalidupto(permitvalidupto.getText().toString());

                databaseHelper.updatevehicals(studentModel);
                alertDialog.dismiss();
                refreshData();
            }
        });
    }

    private void ShowInputDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Vehical.this);
        View view=getLayoutInflater().inflate(R.layout.insert_dialog_vehical,null);
        final EditText registrationdate=view.findViewById(R.id.registrationdate);
        final EditText vehicalno=view.findViewById(R.id.vehicalno);
        final EditText taxvalidupto=view.findViewById(R.id.taxvalidupto);
        final EditText fitnessvalidupto=view.findViewById(R.id.fitnessvalidupto);
        final EditText insurancevalidupto=view.findViewById(R.id.insurancevalidupto);
        final EditText pucvalidupto=view.findViewById(R.id.pucvalidupto);
        final EditText permitvalidupto=view.findViewById(R.id.permitvalidupto);

        Button insertBtn=view.findViewById(R.id.insert_btn);
        al.setView(view);

        final AlertDialog alertDialog=al.show();

        insertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vehicalx studentModel=new vehicalx();
                studentModel.setRegistrationdate(registrationdate.getText().toString());
                studentModel.setVehicalno(vehicalno.getText().toString());
                studentModel.setTaxvalidupto(taxvalidupto.getText().toString());
                studentModel.setFitnessvalidupto(taxvalidupto.getText().toString());
                studentModel.setFitnessvalidupto(fitnessvalidupto.getText().toString());
                studentModel.setInsurancevalidupto(insurancevalidupto.getText().toString());
                studentModel.setPucvalidupto(pucvalidupto.getText().toString());
                studentModel.setPermitvalidupto(permitvalidupto.getText().toString());

                Date date=new Date();
                studentModel.setCreated_at(""+date.getTime());
                databaseHelper.AddVehicals(studentModel);
                alertDialog.dismiss();
                refreshData();
            }
        });
    }



}