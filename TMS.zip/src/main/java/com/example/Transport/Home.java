package com.example.Transport;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Home extends AppCompatActivity {
    CardView Trip;
    CardView Maintainence;
    CardView Employee;
    CardView Vehical;
    private int backpress = 0;
    public static String PREFS_NAME ="MyPrefsFile";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Trip = findViewById(R.id.Trip);
        Maintainence = findViewById(R.id.Maintainence);
        Employee = findViewById(R.id.Employee);
        Vehical = findViewById(R.id.Vehical);



        Trip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Trip.class);
                startActivity(intent);

            }
        });

        Maintainence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Maintainance.class);
                startActivity(intent);
            }
        });

        Vehical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Vehical.class);
                startActivity(intent);
            }
        });

        Employee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,Employee.class);
                startActivity(intent);
            }
        });



        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.Home:
                        return true;
                    case R.id.Exit:
                        overridePendingTransition(0, 0);
                        logoutuser();
                        return true;
                    case R.id.calci:
                        startActivity(new Intent(getApplicationContext()
                                , calci.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
    }

    private void logoutuser() {
        SharedPreferences sharedPreferences =getSharedPreferences(Login.PREFS_NAME,0);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.clear();
        editor.apply();
        Toast.makeText(Home.this, "Log Out successfull", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(Home.this,Login.class));
        finish();
    }


    public void onBackPressed(){
        backpress = (backpress + 1);
        Toast.makeText(getApplicationContext(), " Press Back again to Exit ", Toast.LENGTH_SHORT).show();

        if (backpress>1) {
            this.finish();
        }
    }

}