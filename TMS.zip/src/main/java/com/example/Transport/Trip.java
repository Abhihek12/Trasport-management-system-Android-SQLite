package com.example.Transport;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;
import java.util.List;


public class Trip extends AppCompatActivity {

    DatabaseHelper_trip databaseHelperTrip;
    TextView datalist;
    TextView datalist_count;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip);

        databaseHelperTrip =new DatabaseHelper_trip(Trip.this);
        Button delete=findViewById(R.id.delete_data);
        Button insert=findViewById(R.id.insert_data);
        Button update=findViewById(R.id.update_data);
        Button read=findViewById(R.id.refresh_data);
        datalist=findViewById(R.id.all_data_list);
        datalist_count=findViewById(R.id.data_list_count);

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshData();

            }
        });

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowInputDialog();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showUpdateIdDialog();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog();
            }
        });


    }

    private void refreshData() {
        datalist_count.setText("ALL DATA COUNT : "+ databaseHelperTrip.getTotalCount());

        List<tripx> tripxList = databaseHelperTrip.getAlltrip();
        datalist.setText("");
        for(tripx tripx : tripxList){
            datalist.append("ID : "+ tripx.getId()+" \n | Date : "+ tripx.getDate()+" \n | Vehicalno : "+ tripx.getVehicalno()+" \n | Drivername : "+ tripx.getDrivername()+ " \n | FromWhere : "+ tripx.getFromwhere()+"\n | ToWhere : "+ tripx.getTowhere()+ " \n | Weight : "+ tripx.getWeight()+ " \n | PartyName : "+ tripx.getPartyname()+ " \n | TripFair : "+ tripx.getTripfair()+ " \n | Chalan : "+ tripx.getChalan()+ " \n | DriverAdvance : "+ tripx.getDriveradvance()+ " \n | PartyAdvance : "+ tripx.getPartyadvance()+ " \n | PartryBalance : "+ tripx.getPartybalance()+ "  \n\n\n");
        }
    }

    private void showDeleteDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Trip.this);
        View view=getLayoutInflater().inflate(R.layout.delete_dialog_trip,null);
        al.setView(view);
        final EditText id_input=view.findViewById(R.id.id_input);
        Button delete_btn=view.findViewById(R.id.delete_btn);
        final AlertDialog alertDialog=al.show();

        delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelperTrip.deletetrip(id_input.getText().toString());
                alertDialog.dismiss();
                refreshData();

            }
        });


    }

    private void showUpdateIdDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Trip.this);
        View view=getLayoutInflater().inflate(R.layout.update_id_dialog_trip,null);
        al.setView(view);
        final EditText id_input=view.findViewById(R.id.id_input);
        Button fetch_btn=view.findViewById(R.id.update_id_btn);
        final AlertDialog alertDialog=al.show();


        fetch_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDataDialog(id_input.getText().toString());
                alertDialog.dismiss();
                refreshData();
            }
        });

    }

    private void showDataDialog(final String id) {
        tripx tripx = databaseHelperTrip.gettrip(Integer.parseInt(id));
        AlertDialog.Builder al=new AlertDialog.Builder(Trip.this);
        View view=getLayoutInflater().inflate(R.layout.update_dialog_trip,null);
        final EditText date=view.findViewById(R.id.date);
        final EditText vehicalno=view.findViewById(R.id.vehicalno);
        final EditText drivername=view.findViewById(R.id.drivername);
        final EditText fromwhere=view.findViewById(R.id.fromwhere);
        final EditText towhere=view.findViewById(R.id.towhere);
        final EditText weight=view.findViewById(R.id.weight);
        final EditText partyname=view.findViewById(R.id.partyname);
        final EditText tripfair=view.findViewById(R.id.tripfair);
        final EditText chalan=view.findViewById(R.id.chalan);
        final EditText driveradvance=view.findViewById(R.id.driveradvance);
        final EditText partyadvance=view.findViewById(R.id.partyadvance);
        final EditText partybalance=view.findViewById(R.id.partybalance);


        Button update_btn=view.findViewById(R.id.update_btn);
        al.setView(view);

        date.setText(tripx.getDate());
        vehicalno.setText(tripx.getVehicalno());
        drivername.setText(tripx.getDrivername());
        fromwhere.setText(tripx.getFromwhere());
        towhere.setText(tripx.getTowhere());
        weight.setText(tripx.getWeight());
        partyname.setText(tripx.getPartyname());
        tripfair.setText(tripx.getTripfair());
        chalan.setText(tripx.getChalan());
        driveradvance.setText(tripx.getDriveradvance());
        partyadvance.setText(tripx.getPartyadvance());
        partybalance.setText(tripx.getPartybalance());

        final AlertDialog alertDialog=al.show();
        update_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tripx tripx =new tripx();
                tripx.setDate(date.getText().toString());
                tripx.setId(id);
                tripx.setVehicalno(vehicalno.getText().toString());
                tripx.setDrivername(drivername.getText().toString());
                tripx.setFromwhere(fromwhere.getText().toString());
                tripx.setTowhere(towhere.getText().toString());
                tripx.setWeight(weight.getText().toString());
                tripx.setPartyname(partyname.getText().toString());
                tripx.setTripfair(tripfair.getText().toString());
                tripx.setChalan(chalan.getText().toString());
                tripx.setDriveradvance(driveradvance.getText().toString());
                tripx.setPartyadvance(partyadvance.getText().toString());
                tripx.setPartybalance(partybalance.getText().toString());
                databaseHelperTrip.updateTrip(tripx);
                alertDialog.dismiss();
                refreshData();
            }
        });
    }

    private void ShowInputDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Trip.this);
        View view=getLayoutInflater().inflate(R.layout.insert_dialog_trip,null);
        final EditText date=view.findViewById(R.id.date);
        final EditText vehicalno=view.findViewById(R.id.vehicalno);
        final EditText drivername=view.findViewById(R.id.drivername);
        final EditText fromwhere=view.findViewById(R.id.fromwhere);
        final EditText towhere=view.findViewById(R.id.towhere);
        final EditText weight=view.findViewById(R.id.weight);
        final EditText partyname=view.findViewById(R.id.partyname);
        final EditText tripfair=view.findViewById(R.id.tripfair);
        final EditText chalan=view.findViewById(R.id.chalan);
        final EditText driveradvance=view.findViewById(R.id.driveradvance);
        final EditText partyadvance=view.findViewById(R.id.partyadvance);
        final EditText partybalance=view.findViewById(R.id.partybalance);
        Button insertBtn=view.findViewById(R.id.insert_btn);
        al.setView(view);

        final AlertDialog alertDialog=al.show();

        insertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tripx tripx =new tripx();
                tripx.setDate(date.getText().toString());
                tripx.setVehicalno(vehicalno.getText().toString());
                tripx.setDrivername(drivername.getText().toString());
                tripx.setFromwhere(fromwhere.getText().toString());
                tripx.setTowhere(towhere.getText().toString());
                tripx.setWeight(weight.getText().toString());
                tripx.setPartyname(partyname.getText().toString());
                tripx.setTripfair(tripfair.getText().toString());
                tripx.setChalan(chalan.getText().toString());
                tripx.setDriveradvance(driveradvance.getText().toString());
                tripx.setPartyadvance(partyadvance.getText().toString());
                tripx.setPartybalance(partybalance.getText().toString());
                Date date=new Date();
                tripx.setCreated_at(""+date.getTime());
                databaseHelperTrip.AddTrip(tripx);
                alertDialog.dismiss();
                refreshData();
            }
        });
    }
}