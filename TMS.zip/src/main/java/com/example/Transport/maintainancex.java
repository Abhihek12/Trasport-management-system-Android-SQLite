package com.example.Transport;

public class maintainancex {
    String id="";
    String date="";
    String vehicalno="";
    String drivername="";
    String whattypeofworkdone="";
    String workername="";
    String amount="";
    String amoutpaidtoworker="";
    String remainingamount="";
    String created_at="";

    public maintainancex(String id, String date, String vehicalno, String drivername, String whattypeofworkdone, String workername, String amount, String amountpaidtoworker, String remainingamount, String created_at) {
        this.id = id;
        this.date = date;
        this.vehicalno = vehicalno;
        this.drivername = drivername;
        this.whattypeofworkdone = whattypeofworkdone;
        this.workername = workername;
        this.amount = amount;
        this.amoutpaidtoworker = amountpaidtoworker;
        this.remainingamount = remainingamount;

        this.created_at = created_at;
    }

    public maintainancex(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getVehicalno() {
        return vehicalno;
    }

    public void setVehicalno(String vehicalno) {
        this.vehicalno = vehicalno;
    }

    public String getDrivername() {
        return drivername;
    }

    public void setDrivername(String drivername) {
        this.drivername = drivername;
    }

    public String getWhattypeofworkdone() {
        return whattypeofworkdone;
    }

    public void setWhattypeofworkdone(String whattypeofworkdone) {
        this.whattypeofworkdone = whattypeofworkdone;
    }

    public String getWorkername() {
        return workername;
    }

    public void setWorkername(String workername) {
        this.workername = workername;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmoutpaidtoworker() {
        return amoutpaidtoworker;
    }

    public void setAmoutpaidtoworker(String amoutpaidtoworker) {
        this.amoutpaidtoworker = amoutpaidtoworker;
    }

    public String getRemainingamount() {
        return remainingamount;
    }

    public void setRemainingamount(String remainingamount) {
        this.remainingamount = remainingamount;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}
