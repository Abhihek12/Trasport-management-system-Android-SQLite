package com.example.Transport;

public class vehicalx {
    String id="";
    String registrationdate="";
    String vehicalno="";
    String taxvalidupto="";
    String fitnessvalidupto="";
    String insurancevalidupto="";
    String pucvalidupto="";
    String permitvalidupto="";
    String created_at="";

    public vehicalx(String id, String registrationdatedate, String vehicalno, String taxvalidupto, String fitnessvalidupto, String insurancevalidupto, String pucvalidupto, String permitvalidupto, String created_at) {
        this.id = id;
        this.registrationdate = registrationdatedate;
        this.vehicalno = vehicalno;
        this.taxvalidupto = taxvalidupto;
        this.fitnessvalidupto = fitnessvalidupto;
        this.insurancevalidupto = insurancevalidupto;
        this.pucvalidupto = pucvalidupto;
        this.permitvalidupto = permitvalidupto;
        this.created_at = created_at;
    }

    public vehicalx(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRegistrationdate() {
        return registrationdate;
    }

    public void setRegistrationdate(String registrationdate) {
        this.registrationdate = registrationdate;
    }

    public String getVehicalno() {
        return vehicalno;
    }

    public void setVehicalno(String vehicalno) {
        this.vehicalno = vehicalno;
    }

    public String getTaxvalidupto() {
        return taxvalidupto;
    }

    public void setTaxvalidupto(String taxvalidupto) {
        this.taxvalidupto = taxvalidupto;
    }

    public String getFitnessvalidupto() {
        return fitnessvalidupto;
    }

    public void setFitnessvalidupto(String fitnessvalidupto) {
        this.fitnessvalidupto = fitnessvalidupto;
    }

    public String getInsurancevalidupto() {
        return insurancevalidupto;
    }

    public void setInsurancevalidupto(String insurancevalidupto) {
        this.insurancevalidupto = insurancevalidupto;
    }

    public String getPucvalidupto() {
        return pucvalidupto;
    }

    public void setPucvalidupto(String pucvalidupto) {
        this.pucvalidupto = pucvalidupto;
    }

    public String getPermitvalidupto() {
        return permitvalidupto;
    }

    public void setPermitvalidupto(String permitvalidupto) {
        this.permitvalidupto = permitvalidupto;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}

