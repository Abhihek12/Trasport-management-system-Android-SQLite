package com.example.Transport;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Signup extends AppCompatActivity {
    EditText name, email, contact, password, companyname;
    Button signup;
    boolean isNameValid , isEmailValid, isPhoneValid, isPasswordValid, isCompanynameValid;
    DBHelper_login DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        contact = (EditText) findViewById(R.id.contact);
        password = (EditText) findViewById(R.id.password);
        signup = (Button) findViewById(R.id.signup);
        companyname = (EditText) findViewById(R.id.companyname);
        DB = new DBHelper_login(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SetValidation();

            }
        });


    }



    public void SetValidation() {

        if (companyname.getText().toString().isEmpty()) {
            companyname.setError(getResources().getString(R.string.company_error));
            isNameValid = false;
        } else  {
            isCompanynameValid = true;
        }


        // Check for a valid name.
        if (name.getText().toString().isEmpty()) {
            name.setError(getResources().getString(R.string.name_error));
            isNameValid = false;
        } else  {
            isNameValid = true;
        }

        // Check for a valid email address.
        if (email.getText().toString().isEmpty()) {
            email.setError(getResources().getString(R.string.email_error));
            isEmailValid = false;

        } else if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
                email.setError(getResources().getString(R.string.error_invalid_email));
                isEmailValid = false;

        } else  {
            isEmailValid = true;
        }

        // Check for a valid phone number.
        if (contact.getText().toString().isEmpty()) {
            contact.setError(getResources().getString(R.string.phone_error));
            isPhoneValid = false;
        } else  {
            isPhoneValid = true;
        }

        // Check for a valid password.
        if (password.getText().toString().isEmpty()) {
            password.setError(getResources().getString(R.string.password_error));
            isPasswordValid = false;
        } else if (password.getText().length() < 6) {
            password.setError(getResources().getString(R.string.error_invalid_password));
            isPasswordValid = false;
        } else  {
            isPasswordValid = true;
        }

        if (isNameValid && isEmailValid && isPhoneValid && isPasswordValid && isCompanynameValid) {


            String user = name.getText().toString();
            String pass = password.getText().toString();

            Boolean checkuser = DB.checkusername(user);
            if(checkuser==false) {
                Boolean insert = DB.insertData(user, pass);
                if (insert == true) {
                    Toast.makeText(Signup.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Login.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(Signup.this, "Registration failed", Toast.LENGTH_SHORT).show();
                }
            }

        }



    }
}