package com.example.Transport;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Logout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.Exit);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.Exit:
                        return true;
                    case R.id.Home:
                        overridePendingTransition(0, 0);
                        logoutuser();
                        return true;
                    case R.id.calci:
                        startActivity(new Intent(getApplicationContext()
                                , calci.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
    }

    private void logoutuser() {

        SharedPreferences sharedPreferences =getSharedPreferences(Login.PREFS_NAME,0);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.clear();
        editor.apply();
        editor.commit();
        Toast.makeText(Logout.this, "Log Out successfull", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(Logout.this,Login.class));
        finish();
    }
}