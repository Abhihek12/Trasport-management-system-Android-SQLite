package com.example.Transport;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    public static String PREFS_NAME ="MyPrefsFile";

    EditText username,password;
    TextView signup;
    Button login;
    boolean isusernameValid, isPasswordValid , checkuserpass;
    DBHelper_login DB;
    private int backpress = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login);
        signup = (TextView) findViewById(R.id.signup);
        DB = new DBHelper_login(this);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SetValidation();


            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // redirect to RegisterActivity
                Intent intent = new Intent(getApplicationContext(), Signup.class);
                startActivity(intent);
            }
        });
    }

    public void onBackPressed(){
        backpress = (backpress + 1);
        Toast.makeText(getApplicationContext(), " Press Back again to Exit ", Toast.LENGTH_SHORT).show();

        if (backpress>1) {
            this.finish();
        }
    }

    public void SetValidation() {
        // Check for a valid email address.
        if (username.getText().toString().isEmpty()) {
            username.setError(getResources().getString(R.string.email_error));
            isusernameValid = false;

        } else  {
            isusernameValid = true;
        }

        // Check for a valid password.
        if (password.getText().toString().isEmpty()) {
            password.setError(getResources().getString(R.string.password_error));
            isPasswordValid = false;
        } else if (password.getText().length() < 6) {
            password.setError(getResources().getString(R.string.error_invalid_password));
            isPasswordValid = false;
        } else  {
            isPasswordValid = true;
        }

        if (isusernameValid && isPasswordValid) {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            checkuserpass = DB.checkusernamepassword(user, pass);
            if(checkuserpass==true){

                SharedPreferences sharedPreferences =getSharedPreferences(Login.PREFS_NAME,0);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putBoolean("hasLoggedIn",true);
                editor.commit();
                startActivity(new Intent(Login.this,Home.class));
                finish();

                Toast.makeText(Login.this, "Sign in successfull", Toast.LENGTH_SHORT).show();

            }else{
                Toast.makeText(Login.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }

        }


    }
}