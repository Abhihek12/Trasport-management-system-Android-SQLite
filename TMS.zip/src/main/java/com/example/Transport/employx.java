package com.example.Transport;

public class employx {
    String id="";
    String employeename="";
    String vehicalno="";
    String dateofjoining="";
    String dateofleaving="";
    String advance="";
    String created_at="";

    public employx(String id, String employeename, String vehicalno, String dateofjoining, String dateofleaving, String advance, String created_at) {
        this.id = id;
        this.employeename = employeename;
        this.vehicalno = vehicalno;
        this.dateofjoining = dateofjoining;
        this.dateofleaving = dateofleaving;
        this.advance = advance;
        this.created_at = created_at;
    }

    public employx(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getEmployeename() {
        return employeename;
    }

    public void setEmployeename(String employeename) {
        this.employeename = employeename;
    }

    public String getVehicalno() {
        return vehicalno;
    }

    public void setVehicalno(String vehicalno) {
        this.vehicalno = vehicalno;
    }

    public String getDateofjoining() {
        return dateofjoining;
    }

    public void setDateofjoining(String dateofjoining) {
        this.dateofjoining = dateofjoining;
    }

    public String getDateofleaving() {
        return dateofleaving;
    }

    public void setDateofleaving(String dateofleaving) {
        this.dateofleaving = dateofleaving;
    }

    public String getAdvance() {
        return advance;
    }

    public void setAdvance(String advance) {
        this.advance = advance;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}
