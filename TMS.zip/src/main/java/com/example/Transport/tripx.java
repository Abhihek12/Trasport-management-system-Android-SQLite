package com.example.Transport;


public class tripx {
    String id="";
    String date="";
    String vehicalno="";
    String drivername="";
    String fromwhere="";
    String towhere="";
    String weight="";
    String partyname="";
    String tripfair="";
    String chalan="";
    String driveradvance="";
    String partyadvance="";
    String partybalance="";
    String created_at="";

    public tripx(String id, String date, String vehicalno, String drivername, String fromwhere, String towhere, String weight, String partyname, String tripfair, String chalan, String driveradvance, String partyadvance, String partybalance, String created_at) {
        this.id = id;
        this.date = date;
        this.vehicalno = vehicalno;
        this.drivername = drivername;
        this.fromwhere = fromwhere;
        this.towhere = towhere;
        this.weight = weight;
        this.partyname = partyname;
        this.tripfair = tripfair;
        this.chalan = chalan;
        this.driveradvance = driveradvance;
        this.partyadvance = partyadvance;
        this.partybalance = partybalance;
        this.created_at = created_at;
    }

    public tripx(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getVehicalno() {
        return vehicalno;
    }

    public void setVehicalno(String vehicalno) {
        this.vehicalno = vehicalno;
    }

    public String getDrivername() {
        return drivername;
    }

    public void setDrivername(String drivername) {
        this.drivername = drivername;
    }

    public String getFromwhere() {
        return fromwhere;
    }

    public void setFromwhere(String fromwhere) {
        this.fromwhere = fromwhere;
    }

    public String getTowhere() {
        return towhere;
    }

    public void setTowhere(String towhere) {
        this.towhere = towhere;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getPartyname() {
        return partyname;
    }

    public void setPartyname(String partyname) {
        this.partyname = partyname;
    }

    public String getTripfair() {
        return tripfair;
    }

    public void setTripfair(String tripfair) {
        this.tripfair = tripfair;
    }

    public String getChalan() {
        return chalan;
    }

    public void setChalan(String chalan) {
        this.chalan = chalan;
    }

    public String getDriveradvance() {
        return driveradvance;
    }

    public void setDriveradvance(String driveradvance) {
        this.driveradvance = driveradvance;
    }

    public String getPartyadvance() {
        return partyadvance;
    }

    public void setPartyadvance(String partyadvance) {
        this.partyadvance = partyadvance;
    }

    public String getPartybalance() {
        return partybalance;
    }

    public void setPartybalance(String partybalance) {
        this.partybalance = partybalance;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }


}
