package com.example.Transport;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;
import java.util.List;


public class Maintainance extends AppCompatActivity {

    DatabaseHelper_maintainance databaseHelper;
    TextView datalist;
    TextView datalist_count;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maintainance);

        databaseHelper =new DatabaseHelper_maintainance(Maintainance.this);
        Button delete=findViewById(R.id.delete_data);
        Button insert=findViewById(R.id.insert_data);
        Button update=findViewById(R.id.update_data);
        Button read=findViewById(R.id.refresh_data);
        datalist=findViewById(R.id.all_data_list);
        datalist_count=findViewById(R.id.data_list_count);

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshData();

            }
        });

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShowInputDialog();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showUpdateIdDialog();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteDialog();
            }
        });

    }

    private void refreshData() {
        datalist_count.setText("ALL DATA COUNT : "+ databaseHelper.getTotalCount());

        List<maintainancex> studentModelList= databaseHelper.getAllmaintainance();
        datalist.setText("");
        for(maintainancex studentModel:studentModelList){
            datalist.append("ID : "+studentModel.getId()+" \n  | Date : "+studentModel.getDate()+" \n  | Vehicalno : "+studentModel.getVehicalno()+" \n  | Drivername : "+studentModel.getWhattypeofworkdone()+ " \n  | WhatTypeOfWorkDone : "+studentModel.getDrivername()+"\n  | WorkerName : "+studentModel.getWorkername()+ " \n  | Amount : "+studentModel.getAmount()+ " \n  | AmountPaidToWorker : "+studentModel.getAmoutpaidtoworker()+ " \n  | RemainingAmount : "+studentModel.getRemainingamount()+ "   \n\n\n");
        }
    }

    private void showDeleteDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Maintainance.this);
        View view=getLayoutInflater().inflate(R.layout.delete_dialog_maintainance,null);
        al.setView(view);
        final EditText id_input=view.findViewById(R.id.id_input);
        Button delete_btn=view.findViewById(R.id.delete_btn);
        final AlertDialog alertDialog=al.show();

        delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.deletemaintainance(id_input.getText().toString());
                alertDialog.dismiss();
                refreshData();

            }
        });


    }

    private void showUpdateIdDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Maintainance.this);
        View view=getLayoutInflater().inflate(R.layout.update_id_dialog_maintainance,null);
        al.setView(view);
        final EditText id_input=view.findViewById(R.id.id_input);
        Button fetch_btn=view.findViewById(R.id.update_id_btn);
        final AlertDialog alertDialog=al.show();

        fetch_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDataDialog(id_input.getText().toString());
                alertDialog.dismiss();
                refreshData();
            }
        });

    }

    private void showDataDialog(final String id) {
        maintainancex studentModel= databaseHelper.getmaintainance(Integer.parseInt(id));
        AlertDialog.Builder al=new AlertDialog.Builder(Maintainance.this);
        View view=getLayoutInflater().inflate(R.layout.update_dialog_maintainance,null);
        final EditText date=view.findViewById(R.id.date);
        final EditText vehicalno=view.findViewById(R.id.vehicalno);
        final EditText drivername=view.findViewById(R.id.drivername);
        final EditText whatttypeofworkdone=view.findViewById(R.id.whatypeofworkdone);
        final EditText workername=view.findViewById(R.id.workername);
        final EditText amount=view.findViewById(R.id.amount);
        final EditText amountpaidtoworker=view.findViewById(R.id.amountpaidtoworker);
        final EditText remainingamount=view.findViewById(R.id.remainingamount);

        Button update_btn=view.findViewById(R.id.update_btn);
        al.setView(view);

        date.setText(studentModel.getDate());
        vehicalno.setText(studentModel.getVehicalno());
        drivername.setText(studentModel.getDrivername());
        whatttypeofworkdone.setText(studentModel.getWhattypeofworkdone());
        workername.setText(studentModel.getWorkername());
        amount.setText(studentModel.getAmount());
        amountpaidtoworker.setText(studentModel.getAmoutpaidtoworker());
        remainingamount.setText(studentModel.getRemainingamount());



        final AlertDialog alertDialog=al.show();
        update_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                maintainancex studentModel=new maintainancex();
                studentModel.setDate(date.getText().toString());
                studentModel.setId(id);
                studentModel.setVehicalno(vehicalno.getText().toString());
                studentModel.setDrivername(drivername.getText().toString());
                studentModel.setWhattypeofworkdone(whatttypeofworkdone.getText().toString());
                studentModel.setWorkername(workername.getText().toString());
                studentModel.setAmount(amount.getText().toString());
                studentModel.setAmoutpaidtoworker(amountpaidtoworker.getText().toString());
                studentModel.setRemainingamount(remainingamount.getText().toString());

                databaseHelper.updatemaintainance(studentModel);
                alertDialog.dismiss();
                refreshData();
            }
        });
    }

    private void ShowInputDialog() {
        AlertDialog.Builder al=new AlertDialog.Builder(Maintainance.this);
        View view=getLayoutInflater().inflate(R.layout.insert_dialog_maintainance,null);
        final EditText date=view.findViewById(R.id.date);
        final EditText vehicalno=view.findViewById(R.id.vehicalno);
        final EditText drivername=view.findViewById(R.id.drivername);
        final EditText whattypeofworkdone=view.findViewById(R.id.whatypeofworkdone);
        final EditText workername=view.findViewById(R.id.workername);
        final EditText amount=view.findViewById(R.id.amount);
        final EditText amountpaidtoworker=view.findViewById(R.id.amountpaidtoworker);
        final EditText remainingamount=view.findViewById(R.id.remainingamount);

        Button insertBtn=view.findViewById(R.id.insert_btn);
        al.setView(view);

        final AlertDialog alertDialog=al.show();

        insertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                maintainancex studentModel=new maintainancex();
                studentModel.setDate(date.getText().toString());
                studentModel.setVehicalno(vehicalno.getText().toString());
                studentModel.setDrivername(drivername.getText().toString());
                studentModel.setWhattypeofworkdone(whattypeofworkdone.getText().toString());
                studentModel.setWorkername(workername.getText().toString());
                studentModel.setAmount(amount.getText().toString());
                studentModel.setAmoutpaidtoworker(amountpaidtoworker.getText().toString());
                studentModel.setRemainingamount(remainingamount.getText().toString());

                Date date=new Date();
                studentModel.setCreated_at(""+date.getTime());
                databaseHelper.Addmaintainance(studentModel);
                alertDialog.dismiss();
                refreshData();
            }
        });
    }

}
