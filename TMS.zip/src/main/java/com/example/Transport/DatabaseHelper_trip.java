package com.example.Transport;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper_trip extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=4;
    private static final String  DATABASE_NAME="trip_db";
    private static final String TABLE_NAME="trips";
    private static final String ID="id";
    private static final String date="date";
    private static final String vehicalno="vehicalno";
    private static final String drivername="drivername";
    private static final String fromwhere="fromwhere";
    private static final String towhere="towhere";
    private static final String weight="weight";
    private static final String partyname="partyname";
    private static final String tripfair="tripfair";
    private static final String chalan="chalan";
    private static final String driveradvance="driveradvance";
    private static final String partyadvance="partyadvance";
    private static final String partybalance="partybalance";
    private static final String created_at="created_at";


    public DatabaseHelper_trip(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
        String table_query="CREATE TABLE if not EXISTS "+TABLE_NAME+
                "("+
                ID+" INTEGER PRIMARY KEY,"+
                date+" TEXT ,"+
                vehicalno+" TEXT ,"+
                drivername+ " TEXT ,"+
                fromwhere+" TEXT ,"+
                towhere+" TEXT ,"+
                weight+" TEXT ,"+
                partyname+" TEXT ,"+
                tripfair+" TEXT ,"+
                chalan+" TEXT ,"+
                driveradvance+" TEXT ,"+
                partyadvance+" TEXT ,"+
                partybalance+" TEXT ,"+

                created_at+ " TEXT "+
                ")";
        db.execSQL(table_query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    }

    public void AddTrip(tripx tripx){
        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues contentValues=new ContentValues();
        contentValues.put(date, tripx.getDate());
        contentValues.put(vehicalno, tripx.getVehicalno());
        contentValues.put(drivername, tripx.getDrivername());
        contentValues.put(fromwhere, tripx.getFromwhere());
        contentValues.put(towhere, tripx.getTowhere());
        contentValues.put(weight, tripx.getWeight());
        contentValues.put(partyname, tripx.getPartyname());
        contentValues.put(tripfair, tripx.getTripfair());
        contentValues.put(chalan, tripx.getChalan());
        contentValues.put(driveradvance, tripx.getDriveradvance());
        contentValues.put(partyadvance, tripx.getPartyadvance());
        contentValues.put(partybalance, tripx.getPartybalance());
        contentValues.put(created_at, tripx.getCreated_at());
        db.insert(TABLE_NAME,null,contentValues);
        db.close();
    }

    public tripx gettrip(int id){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.query(TABLE_NAME,new String[]{ID,date,vehicalno,drivername,fromwhere,towhere,weight,partyname,tripfair,chalan,driveradvance,partyadvance,partybalance,created_at},ID+" = ?",new String[]{String.valueOf(id)},null,null,null);
        if(cursor!=null){
            cursor.moveToFirst();
        }
        tripx tripx =new tripx(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8),cursor.getString(9),cursor.getString(10),cursor.getString(11),cursor.getString(12),cursor.getString(13));
        db.close();
        return tripx;
    }

    public List<tripx> getAlltrip(){
        List<tripx> tripxList =new ArrayList<>();
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                tripx tripx =new tripx(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8),cursor.getString(9),cursor.getString(10),cursor.getString(11),cursor.getString(12),cursor.getString(13));
                tripxList.add(tripx);
            }
            while (cursor.moveToNext());

        }
        db.close();
        return tripxList;
    }

    public int updateTrip(tripx tripx){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(date, tripx.getDate());
        contentValues.put(vehicalno, tripx.getVehicalno());
        contentValues.put(drivername, tripx.getDrivername());
        contentValues.put(fromwhere, tripx.getFromwhere());
        contentValues.put(towhere, tripx.getTowhere());
        contentValues.put(weight, tripx.getWeight());
        contentValues.put(partyname, tripx.getPartyname());
        contentValues.put(tripfair, tripx.getTripfair());
        contentValues.put(chalan, tripx.getChalan());
        contentValues.put(driveradvance, tripx.getDriveradvance());
        contentValues.put(partyadvance, tripx.getPartyadvance());
        contentValues.put(partybalance, tripx.getPartybalance());

        return db.update(TABLE_NAME,contentValues,ID+"=?",new String[]{String.valueOf(tripx.getId())});

    }

    public void deletetrip(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(TABLE_NAME,ID+"=?",new String[]{id});
        db.close();
    }

    public int getTotalCount(){
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase sqLiteDatabase=this.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery(query,null);
        return cursor.getCount();
    }
}

class DatabaseHelper_maintainance extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=2;
    private static final String  DATABASE_NAME="maintainance_db)";
    private static final String TABLE_NAME="maintainances";
    private static final String ID="id";
    private static final String date="date";
    private static final String vehicalno="vehicalno";
    private static final String drivername="drivername";
    private static final String whattypeofworkdone="whattypeofworkdone";
    private static final String workername="workername";
    private static final String amount="amount";
    private static final String amountpaidtoworker="amountpaidtoworker";
    private static final String remainingamount="remainingamount";
    private static final String created_at="created_at";


    public DatabaseHelper_maintainance(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
        String table_query="CREATE TABLE if not EXISTS "+TABLE_NAME+
                "("+
                ID+" INTEGER PRIMARY KEY,"+
                date+" TEXT ,"+
                vehicalno+" TEXT ,"+
                drivername+" TEXT ,"+
                whattypeofworkdone+ " TEXT ,"+
                workername+" TEXT ,"+
                amount+" TEXT ,"+
                amountpaidtoworker+" TEXT ,"+
                remainingamount+" TEXT ,"+


                created_at+ " TEXT "+
                ")";
        db.execSQL(table_query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    }

    public void Addmaintainance(maintainancex studentModel){
        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues contentValues=new ContentValues();
        contentValues.put(date,studentModel.getDate());
        contentValues.put(vehicalno,studentModel.getVehicalno());
        contentValues.put(drivername,studentModel.getDrivername());
        contentValues.put(whattypeofworkdone,studentModel.getWhattypeofworkdone());
        contentValues.put(workername,studentModel.getWorkername());
        contentValues.put(amount,studentModel.getAmount());
        contentValues.put(amountpaidtoworker,studentModel.getAmoutpaidtoworker());
        contentValues.put(remainingamount,studentModel.getRemainingamount());
        contentValues.put(created_at,studentModel.getCreated_at());
        db.insert(TABLE_NAME,null,contentValues);
        db.close();
    }

    public maintainancex getmaintainance(int id){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.query(TABLE_NAME,new String[]{ID,date,vehicalno,drivername,whattypeofworkdone,workername,amount,amountpaidtoworker,remainingamount,created_at},ID+" = ?",new String[]{String.valueOf(id)},null,null,null);
        if(cursor!=null){
            cursor.moveToFirst();
        }
        maintainancex studentModel=new maintainancex(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8),cursor.getString(9));
        db.close();
        return studentModel;
    }

    public List<maintainancex> getAllmaintainance(){
        List<maintainancex> studentModelList=new ArrayList<>();
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                maintainancex studentModel=new maintainancex(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8),cursor.getString(9));
                studentModelList.add(studentModel);
            }
            while (cursor.moveToNext());

        }
        db.close();
        return studentModelList;
    }

    public int updatemaintainance(maintainancex studentModel){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(date,studentModel.getDate());
        contentValues.put(vehicalno,studentModel.getVehicalno());
        contentValues.put(drivername,studentModel.getDrivername());
        contentValues.put(whattypeofworkdone,studentModel.getWhattypeofworkdone());
        contentValues.put(workername,studentModel.getWorkername());
        contentValues.put(amount,studentModel.getAmount());
        contentValues.put(amountpaidtoworker,studentModel.getAmoutpaidtoworker());
        contentValues.put(remainingamount,studentModel.getRemainingamount());


        return db.update(TABLE_NAME,contentValues,ID+"=?",new String[]{String.valueOf(studentModel.getId())});

    }

    public void deletemaintainance(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(TABLE_NAME,ID+"=?",new String[]{id});
        db.close();
    }

    public int getTotalCount(){
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase sqLiteDatabase=this.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery(query,null);
        return cursor.getCount();
    }
}

class DatabaseHelper_vehicals extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=3;
    private static final String  DATABASE_NAME="vehicals_db";
    private static final String TABLE_NAME="vehicals";
    private static final String ID="id";
    private static final String registrationdate="registartiondate";
    private static final String vehicalno="vehicalno";
    private static final String taxvalidupto="taxvalidupto";
    private static final String fitnesssvalidupto="fitnessvalidupto";
    private static final String insurancevalidupto="insurancevalidupto";
    private static final String pucvalidupto="pucvalidupto";
    private static final String permitvalidupto="permitvalidupto";

    private static final String created_at="created_at";


    public DatabaseHelper_vehicals(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
        String table_query="CREATE TABLE if not EXISTS "+TABLE_NAME+
                "("+
                ID+" INTEGER PRIMARY KEY,"+
                registrationdate+" TEXT ,"+
                vehicalno+" TEXT ,"+
                taxvalidupto+" TEXT ,"+
                fitnesssvalidupto+ " TEXT ,"+
                insurancevalidupto+" TEXT ,"+
                pucvalidupto+" TEXT ,"+
                permitvalidupto+" TEXT ,"+
                created_at+ " TEXT "+
                ")";
        db.execSQL(table_query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    }

    public void AddVehicals(vehicalx studentModel3){
        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues contentValues=new ContentValues();
        contentValues.put(registrationdate, studentModel3.getRegistrationdate());
        contentValues.put(vehicalno, studentModel3.getVehicalno());
        contentValues.put(taxvalidupto, studentModel3.getTaxvalidupto());
        contentValues.put(fitnesssvalidupto, studentModel3.getFitnessvalidupto());
        contentValues.put(insurancevalidupto, studentModel3.getInsurancevalidupto());
        contentValues.put(pucvalidupto, studentModel3.getPucvalidupto());
        contentValues.put(permitvalidupto, studentModel3.getPermitvalidupto());
        contentValues.put(created_at, studentModel3.getCreated_at());
        db.insert(TABLE_NAME,null,contentValues);
        db.close();
    }

    public vehicalx getvehical(int id){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.query(TABLE_NAME,new String[]{ID,registrationdate,vehicalno,taxvalidupto,fitnesssvalidupto,insurancevalidupto,pucvalidupto,permitvalidupto,created_at},ID+" = ?",new String[]{String.valueOf(id)},null,null,null);
        if(cursor!=null){
            cursor.moveToFirst();
        }
        vehicalx studentModel3 =new vehicalx(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8));
        db.close();
        return studentModel3;
    }

    public List<vehicalx> getAllvehicals(){
        List<vehicalx> studentModelList=new ArrayList<>();
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                vehicalx studentModel=new vehicalx(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6),cursor.getString(7),cursor.getString(8));
                studentModelList.add(studentModel);
            }
            while (cursor.moveToNext());

        }
        db.close();
        return studentModelList;
    }

    public int updatevehicals(vehicalx studentModel3){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(registrationdate, studentModel3.getRegistrationdate());
        contentValues.put(vehicalno, studentModel3.getVehicalno());
        contentValues.put(taxvalidupto, studentModel3.getTaxvalidupto());
        contentValues.put(fitnesssvalidupto, studentModel3.getFitnessvalidupto());
        contentValues.put(insurancevalidupto, studentModel3.getInsurancevalidupto());
        contentValues.put(pucvalidupto, studentModel3.getPucvalidupto());
        contentValues.put(permitvalidupto, studentModel3.getPermitvalidupto());
        return db.update(TABLE_NAME,contentValues,ID+"=?",new String[]{String.valueOf(studentModel3.getId())});

    }

    public void deletevehicals(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(TABLE_NAME,ID+"=?",new String[]{id});
        db.close();
    }

    public int getTotalCount(){
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase sqLiteDatabase=this.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery(query,null);
        return cursor.getCount();
    }
}

class DatabaseHelper_employee extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=10;
    private static final String  DATABASE_NAME="employee_db";
    private static final String TABLE_NAME="employee";
    private static final String ID="id";
    private static final String employeename="employeename";
    private static final String vehicalno ="vehicalno";
    private static final String dateofjoining ="dateofjoining";
    private static final String dateofleaving="dateofleaving";
    private static final String advance ="advance";
    private static final String created_at="created_at";


    public DatabaseHelper_employee(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
        String table_query="CREATE TABLE if not EXISTS "+TABLE_NAME+
                "("+
                ID+" INTEGER PRIMARY KEY,"+
                employeename+" TEXT ,"+
                vehicalno +" TEXT ,"+
                dateofjoining + " TEXT ,"+
                dateofleaving + " TEXT ,"+
                advance+" TEXT ,"+
                created_at+ " TEXT "+
                ")";
        db.execSQL(table_query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    }

    public void Addemployee(employx studentModel){
        SQLiteDatabase db=this.getWritableDatabase();

        ContentValues contentValues=new ContentValues();
        contentValues.put(employeename,studentModel.getEmployeename());
        contentValues.put(vehicalno,studentModel.getVehicalno());
        contentValues.put(dateofjoining,studentModel.getDateofjoining());
        contentValues.put(dateofleaving,studentModel.getDateofleaving());
        contentValues.put(advance,studentModel.getAdvance());
        contentValues.put(created_at,studentModel.getCreated_at());
        db.insert(TABLE_NAME,null,contentValues);
        db.close();
    }

    public employx getemployee(int id){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.query(TABLE_NAME,new String[]{ID,employeename,vehicalno,dateofjoining,dateofleaving,advance,created_at},ID+" = ?",new String[]{String.valueOf(id)},null,null,null);
        if(cursor!=null){
            cursor.moveToFirst();
        }
        employx studentModel=new employx(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5),cursor.getString(6));
        db.close();
        return studentModel;
    }

    public List<employx> getAllemployee(){
        List<employx> studentModelList=new ArrayList<>();
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                employx studentModel=new employx(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(4),cursor.getString(3),cursor.getString(5),cursor.getString(6));
                studentModelList.add(studentModel);
            }
            while (cursor.moveToNext());

        }
        db.close();
        return studentModelList;
    }

    public int updateemployee(employx studentModel){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(employeename,studentModel.getEmployeename());
        contentValues.put(vehicalno,studentModel.getVehicalno());
        contentValues.put(dateofjoining,studentModel.getDateofjoining());
        contentValues.put(dateofleaving,studentModel.getDateofleaving());
        contentValues.put(advance,studentModel.getAdvance());
        return db.update(TABLE_NAME,contentValues,ID+"=?",new String[]{String.valueOf(studentModel.getId())});

    }

    public void deleteemployee(String id){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(TABLE_NAME,ID+"=?",new String[]{id});
        db.close();
    }

    public int getTotalCount(){
        String query="SELECT * from "+TABLE_NAME;
        SQLiteDatabase sqLiteDatabase=this.getReadableDatabase();
        Cursor cursor=sqLiteDatabase.rawQuery(query,null);
        return cursor.getCount();
    }
}

class DBHelper_login extends SQLiteOpenHelper {

    public static final String DBNAME = "Login.db";
    public DBHelper_login(Context context) {
        super(context, "Login.db", null, 1);
    }



    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
    }
    public Boolean insertData(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = MyDB.insert("users", null, contentValues);
        if(result==-1) return false;
        else
            return true;
    }

    public Boolean checkusername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;

    }
}

